RodriSmooth - projeto Android

Este ZIP contém um projeto Android completo e mínimo para gerar o APK.

Aplicação:
- Nome: RodriSmooth
- Application ID: com.rodrismooth.app
- Versão: 1.0
- Min SDK: 23
- Target/Compile SDK: 35

O projeto contém a interface inicial do RodriSmooth. O botão "Escolher vídeo" é atualmente apenas a interface inicial; ainda não implementa edição de vídeo.

Para serviços de compilação online, envie o conteúdo deste ZIP como projeto Android/Gradle.
